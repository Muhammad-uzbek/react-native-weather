import React from "react";
import { View, Text, Image } from "react-native";
import styles from "./styles";
const search = require("../../../assets/search.png");
const notfound = require("../../../assets/notfound.png");
import { variables } from "../../theme";
interface Props {
  error: Boolean;
  darkTheme: Boolean;
}
const CardStatus: React.FC<Props> = ({ error, darkTheme }) => {
  return (
    <View style={[
      styles.contentCard,
      darkTheme ? { backgroundColor: variables.colors.black400 } : {}
    ]}>
      <Image
        style={styles.img}
        source={error ? notfound : search}
        resizeMode="contain"
      />
      {error ? (
        <View>
          <Text style={[styles.title, darkTheme ? {color:variables.colors.white500}:{}]}>Xato qidiruv berdizgiz.</Text>
          <Text style={[styles.text, darkTheme ? {color:variables.colors.gray500}:{}]}>
            Xatolik yuz berdi. Iltimos, qayta urinib ko'ring.
          </Text>
        </View>
      ) : (
        <View>
          <Text style={[styles.title, darkTheme ? {color:variables.colors.white500}:{}]}>Qidiring.</Text>
          <Text style={[styles.text, darkTheme ? {color:variables.colors.gray500}:{}]}>
            Ob-havo haqida ma'lumot olish uchun shahar nomini qidiring yoki qayta urinib ko'ring.
          </Text>
        </View>
      )}
    </View>
  );
};

export default CardStatus;
