import React from "react";
import { View, Text, Image } from "react-native";
import { variables } from "../../theme";

import styles from "./styles";

interface Props {
  nameIcon: String;
  title: String;
  img: Object;
  // description: String;
  value: String;
  darkTheme: Boolean;
}

const CardDetail: React.FC<Props> = ({
  nameIcon,
  title,
  img,
  darkTheme,
  // description,
  value,
}) => {
  return (
    <View style={[styles.contentCard, darkTheme ? {backgroundColor: variables.colors.black400}: {}]}>
      <View
        style={{
          flex: 7,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Image
          style={{ height: 42, width: 42 }}
          source={img}
          resizeMode="contain"
        />
      </View>
      <View style={{ flex: 5 }}>
        <Text style={[styles.value, darkTheme ? {color: variables.colors.white500}: {}]}>{value}</Text>
        <Text style={[styles.title, darkTheme ? {color: variables.colors.gray500}: {}]}>{title}</Text>
        {/* <Text style={styles.description}>{description}</Text> */}
      </View>
    </View>
  );
};

export default CardDetail;
