import React from "react";
import { View, Text, Image } from "react-native";
import { Feather as Icon } from "@expo/vector-icons";

import styles from "./styles";
import { variables } from "../../theme";
import { Data } from "../../pages/home";
interface Props {
  data: Data;
  darkTheme: boolean;
}
const returnHaftaKuniVaSana = () => {
  const haftaKunlari=["Yakshanba","Dushanba","Seshanba","Chorshanba","Payshanba","Juma","Shanba"];
  const oylar=["Yanvar","Fevral","Mart","Aprel","May","Iyun","Iyul","Avqust","Sentyabr","Oktyabr","Noyabr","Dekabr"];
  const bugun = new Date();
  const haftaKuni = haftaKunlari[bugun.getDay()];
  return `${haftaKuni}, ${bugun.getDate()}-${oylar[bugun.getMonth()]}`;
}
const CardMain: React.FC<Props> = ({ data, darkTheme }) => {
  return (
    <View style={[styles.contentCard, darkTheme ? {backgroundColor: variables.colors.black400}: {}]}>
      <View style={styles.inline }>
        <Icon name="map-pin" size={32} color={variables.colors.orange600} />
        <View style={{ marginLeft: 16 }}>
          <Text style={[styles.nameCity, darkTheme ? {color: variables.colors.white500}: {}]}>
            {data.city}, {data.uf}
          </Text>
          <Text style={[styles.data, darkTheme ? {color: variables.colors.gray500}: {}]}>
            {returnHaftaKuniVaSana()}
          </Text>
        </View>
      </View>

      <View style={[styles.inline, { justifyContent: "space-between" }]}>
        <Text style={[styles.tem, darkTheme ? {color: variables.colors.white500}: {}]}>{data.temp.toFixed(0)}°</Text>
        <Image
          style={styles.img}
          source={require("../../../assets/cloudy.png")}
          resizeMode="contain"
        />
      </View>

      <View style={styles.inline}>
        <View
          style={[
            styles.inline,
            {
              marginRight: 24,
            },
          ]}
        >
          <Icon name="arrow-down" size={16} color={darkTheme ? variables.colors.gray300: variables.colors.gray500} />
          <Text style={[styles.temps, darkTheme ? {color: variables.colors.gray300}: {}]}>Min: {data.temp_min.toFixed(0)}</Text>
        </View>
        <View style={styles.inline}>
          <Icon name="arrow-up" size={16} color={darkTheme ? variables.colors.gray300: variables.colors.gray500} />
          <Text style={[styles.temps, darkTheme ? {color: variables.colors.gray300}: {}]}>Max: {data.temp_max.toFixed(0)}</Text>
        </View>
      </View>
    </View>
  );
};

export default CardMain;
