import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ActivityIndicator,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Animated,
} from "react-native";
import { Feather as Icon, Fontisto, AntDesign, MaterialCommunityIcons } from "@expo/vector-icons";

import CardDetail from "../../components/CardDetail";
import CardStatus from "../../components/CardStatus";
import CardMain from "../../components/CardMain";

import styles from "./styles";
import { variables } from "../../theme";
import api from "../../services";

import {
  fadeInTop,
  findOut,
  opacityAnimated,
  changeColorText,
} from "../../animated";

const humidity_img = require("../../../assets/humidity.png");
const wind_img = require("../../../assets/wind.png");
const sun_img = require("../../../assets/sun.png");
const clouds_img = require("../../../assets/clouds.png");
export interface Data {
  city: String;
  uf: String;
  temp: number;
  temp_min: number;
  temp_max: number;
}

interface Details {
  wind: number;
  visibility: number;
  humidity: number;
  clouds: number;
}

const Home = () => {
  const [nameCity, setNameCity] = useState("");
  const [error, setError] = useState(false);
  const [darkTheme, setDarkTheme] = useState(false);
  const [data, setData] = useState<Data>({} as Data);
  const [details, setDetails] = useState<Details>({} as Details);

  const [loading, setLoading] = useState(false);
  const [cityImg, setCityImg] = useState("");
  const scrollY = new Animated.Value(0);
  async function handleCity() {
    
    setLoading(true);
    return api
      .get(`?q=${nameCity}`)
      .then((res) => {
        const data = res.data;
        setData({
          city: data.name,
          uf: data.sys.country,
          temp: data.main.temp,
          temp_min: data.main.temp_min,
          temp_max: data.main.temp_max,
        });

        setDetails({
          wind: data.wind.speed,
          visibility: data.visibility,
          humidity: data.main.humidity,
          clouds: data.clouds.all,
        });

        setLoading(false);
      })
      .catch((error) => {
        console.log(error);

        setLoading(false);
        setData({} as Data);
        setDetails({} as Details);
        setError(true);
      });
  }

  useEffect(() => {
    if (nameCity === "") {
      return setError(false);
    }
  }, [nameCity]);

  return (
    <View style={[
      styles.container,
      darkTheme ? { backgroundColor: variables.colors.black600 } : {},
    ]}>
      <View style={[
        styles.cardHeader,
        darkTheme ? { backgroundColor: variables.colors.orange600 } : {},
        ]}>
        <View style={styles.header}>
          <Icon
            name="refresh-ccw"
            size={22}
            color={"transparent"}
          />
          <Text style={styles.headerTitle}>Zamin ob-havo</Text>
          <View>
            <TouchableOpacity
              onPress={() => (darkTheme ? setDarkTheme(false) : setDarkTheme(true))}>
              <View >
                <Fontisto name={darkTheme ? "night-clear": "day-sunny"} size={24} color={"white"} style={{paddingTop:3, paddingLeft:4.5}} />
              </View>
            </TouchableOpacity>
        </View>
        </View>

        {/* Input search */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            marginTop: 24,
          }}
        >
          <View style={{ width: "78%" }}>
          <MaterialCommunityIcons name="city-variant-outline" size={24} color="white" style={styles.iconInput} />
            <TextInput
              placeholder="Qidirish.."
              placeholderTextColor={variables.colors.white500 + "80"}
              selectionColor={variables.colors.white500 + "18"}
              autoCapitalize="words"
              style={styles.input}
              value={nameCity}
              onChangeText={(value) => setNameCity(value)}
              onSubmitEditing={() => {
                handleCity();
              }}
            />
          </View>

          <View style={{ marginLeft: "4%", width: "18%" }}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => {
                handleCity();
              }}
              style={styles.searchBtn}
            >
              {loading ? (
                <ActivityIndicator
                  size="small"
                  color={variables.colors.white500}
                />
              ) : (
                <AntDesign name="search1" size={24} color="white" />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <Animated.View
        style={[
          styles.body,
          {
            marginTop: -140,
            zIndex: findOut(scrollY),
            bottom: fadeInTop(scrollY),
            opacity: opacityAnimated(scrollY),
          },
        ]}
      >
        {data.uf?.length > 0 ? (
          <CardMain data={data}  darkTheme={darkTheme}/>
        ) : (
          <CardStatus darkTheme={darkTheme} error={error} />
        )}
      </Animated.View>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        style={{ marginTop: -260, zIndex: 2 }}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
      >
        <View style={{ height: 264, display: "flex" }} />

        <View style={styles.body}>
          <Animated.Text
            style={[styles.info, { color: changeColorText(scrollY) }, darkTheme ? { color: variables.colors.gray200 } : {}]}
          >
            Batafsil
          </Animated.Text>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{
            paddingHorizontal: 26,
          }}
          style={{ marginTop: 8 }}
        >
          <CardDetail
            nameIcon="droplet"
            title="Namlik"
            darkTheme={darkTheme}
            img={humidity_img}
            value={`${details.humidity ? details.humidity : 0}%`}
          />

          <CardDetail
            nameIcon="wind"
            title="Shamol"
            darkTheme={darkTheme}
            img={wind_img}
            value={`${details.wind ? details.wind : 0} km/h`}
          />

          <CardDetail
            nameIcon="sun"
            title="Quyosh"
            darkTheme={darkTheme}
            img={sun_img}
            value={`${details.visibility ? details.visibility : 0}km`}
          />

          <View style={{ marginRight: -12 }}>
            <CardDetail
              nameIcon="cloud"
              title="Bulut"
              darkTheme={darkTheme}
              img={clouds_img}
              value={`${details.clouds ? details.clouds : 0}%`}
            />
          </View>
        </ScrollView>
        <View style={{ height: 64 }} />
      </Animated.ScrollView>
    </View>
  );
};

export default Home;
